import os

def remove_lines_in_dir():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    for file in os.listdir(script_dir):
        if file.endswith(".md"):
            file_path = os.path.join(script_dir, file)
            with open(file_path, "r") as f:
                lines = f.readlines()
            lines = remove_lines(lines)
            with open(file_path, "w") as f:
                f.writelines(lines)

def remove_lines(lines):
    # Iterate through the lines and remove any that match the pattern
    lines = [line for line in lines if "cover:" not in line and "image:" not in line and "alt:" not in line]
    return lines

remove_lines_in_dir()
