import os
import csv
import re

directory = ""
missing_directory = ""

def extract_images(directory, missing_directory):
    # Initialize an empty list to store the image information
    image_list = []

    # Iterate over all subdirectories and files in the parent directory
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith(".md"):
                file_path = os.path.join(root, file)
                # Open the file and read its contents
                with open(file_path, 'r') as md_file:
                    contents = md_file.read()
                    # Extract the title
                    if "title:" in contents:
                        start_index = contents.index("title: ") + 7
                        end_index = contents.index("\n", start_index)
                        title = contents[start_index:end_index].strip()
                    else:
                        title = "not found"
                    # Extract the type
                    if "type:" in contents:
                        start_index = contents.index("type: ") + 6
                        end_index = contents.index("\n", start_index)
                        type_ = contents[start_index:end_index].strip()
                    else:
                        type_ = "not found"
                    # Extract the category
                    if "categories:" in contents:
                        start_index = contents.index("categories: ") + 12
                        end_index = contents.index("\n", start_index)
                        category = contents[start_index:end_index]
                        # Get rid of the brackets and quote marks
                        category = category.replace("[","").replace("]","").replace("\"","")
                    else:
                        category = "not found"
                    # Extract the tags
                    if "tags:" in contents:
                        start_index = contents.index("tags: ") + 7
                        end_index = contents.index("\n", start_index)
                        tags = contents[start_index:end_index].strip()
                    else:
                        tags = "not found"
                    # Construct the prompt
                    prompt = f"{title}, {type_} from {tags} in {category}"
                    # Remove any special characters other than spaces from the prompt
                    prompt = re.sub(r'[^\w\s]', '', prompt)
                    # Check if the file contains a cover image
                    if "cover:" in contents:
                        # Extract the image URL
                        start_index = contents.index("image: ") + 7
                        end_index = contents.index(".webp") + 5
                        image_url = contents[start_index:end_index].strip()
                        filename = image_url.split('/')[-1]
                        # check if the image is missing from the specified directory
                        file_missing = True
                        for root_missing, dirs_missing, files_missing in os.walk(missing_directory):
                            for file_missing in files_missing:
                                if file_missing == filename:
                                    file_missing = False
                                    break
                        if file_missing:
                            # Create a link to search Google with the full phrase from the first column
                            google_link = "https://www.google.com/search?q=" + prompt.replace(" ", "+")
                            # Add the image information to the list
                            image_list.append([prompt, image_url, filename, google_link])
    #write the data to csv file
    with open('images.csv', mode='w') as file:
        writer = csv.writer(file)
        writer.writerow(["prompt", "image_url", "filename", "google_link"])
        for row in image_list:
            writer.writerow(row)
    print(f"{len(image_list)} images found and written to images.csv")

if __name__ == "__main__":
    # Provide the parent directory path as input
    extract_images("./../osoappliance/content/directory/", "./../osoappliance/static/img/directory-images/")
