# README

This script is used to process images in a folder called "processing". It will resize the images to a width of 720 pixels and save them as webp format in a new folder called "img-output". **Please note that after processing, the original image files will be deleted**.

## Dependencies
- os
- PIL

## Usage
1. Place the images you want to process in a folder called "processing" in the same directory as the script.
2. Run the script.
3. The processed images will be saved in the "img-output" folder.

## Note 
Be sure to use the correct path for the folder containing the images and the output folder.

