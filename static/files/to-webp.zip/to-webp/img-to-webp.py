import os
from PIL import Image

folder_path = "processing"

# Create the output directory
output_folder = "img-output"
os.makedirs(output_folder, exist_ok=True)

# Get all the image files in the folder
image_files = [f for f in os.listdir(folder_path) if f.endswith(("jpg", "jpeg", "png"))]

# Counter for naming the images
counter = 1

for file in image_files:
    # Open the image file
    image = Image.open(os.path.join(folder_path, file))

    # Resize the image
    width, height = image.size
    new_height = int(height * 720 / width)
    image = image.resize((720, new_height))

    # Save the image as webp
    new_file_name = str(counter) + ".webp"
    new_file_path = os.path.join(output_folder, new_file_name)
    image.save(new_file_path, "webp")

    # Delete the original image file
    os.remove(os.path.join(folder_path, file))

    # Increment the counter
    counter += 1
