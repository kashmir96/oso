import os
import re

path = os.getcwd()

path_value = "<path_value>"
image = 1
max_image = 5
edited_files = 0

for filename in os.listdir(path):
    if filename.endswith('.md'):
        company = re.sub(r'\W+', '', filename.split(".")[0]) # ignore any symbols or special characters
        with open(filename, 'r') as file:
            lines = file.readlines()
            subject = re.sub(r'\W+', '', [line for line in lines if line.startswith("categories:")][0].split(":")[1]) # ignore any symbols or special characters
            filetype = re.sub(r'\W+', '', [line for line in lines if line.startswith("type:")][0].split(":")[1]) # ignore any symbols or special characters
        front_matter_end = lines.index("---\n", lines.index("---\n")+1)
        # insert the lines just before the end of the front matter
        lines.insert(front_matter_end, "cover:\n image: /img/{}/{}.webp\n alt: '{} from {}'\n".format(path_value, image, subject, company))
        with open(filename, 'w') as file:
            file.writelines(lines)
        image += 1
        if image > max_image:
            image = 1
        edited_files += 1
        
print("Number of edited md files: {}".format(edited_files))
